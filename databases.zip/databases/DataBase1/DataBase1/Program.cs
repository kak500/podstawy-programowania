﻿using System;
using System.Data.SqlClient;

namespace DataBase1
{
    class Program
    {
        static void Main(string[] args)
        {
            string sql, Output="";
            SqlDataReader read = null;
            //SqlCommand command;

            
            //SqlConnection conn = new SqlConnection("Data Source=localhost\\SQLEXPRESS;Initial Catalog=komis;Integrated Security=true");
            SqlConnection conn = new SqlConnection("Data Source=localhost\\SQLEXPRESS;Initial Catalog=komis;User ID=anna;Password=1234");

            try
            {
                conn.Open();
                Console.WriteLine("prawidłowe połączenie z  bazą komis");
                
                sql = "Select [id], [name], [surname] from [user]"; // Zapytanie
                SqlCommand command = new SqlCommand(sql, conn);
                read = command.ExecuteReader();

                while (read.Read())
                {
                    Console.WriteLine("Imie: {0}, nazwisko: {1}", read[1],read[2]);
                    //Output = Output + read.GetValue(0) + " - " + read.GetValue(1) + " " + read.GetValue(2) + "\n";
                }

                //Console.WriteLine(Output);
                //conn.Close();
            }
            catch (SqlException e)
            {
                Console.WriteLine(e.Message);

            }
            finally
            {
                if (conn!=null)
                {
                    conn.Close();
                }

                if (read != null)
                {
                    read.Close();
                }
            }
            Console.ReadKey();
        }
    }
}
