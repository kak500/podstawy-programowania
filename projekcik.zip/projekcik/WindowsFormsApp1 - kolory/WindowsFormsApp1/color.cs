﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class color : Form
    {
        public color()
        {
            InitializeComponent();
        }

        private void btnColorClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnColorCloseApp_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnShowWindow_Click(object sender, EventArgs e)
        {
            string rawSize = inputSize.Text;
            int winSize;
            if (int.TryParse(rawSize, out winSize) && winSize > 0 && winSize <= 250)
            {
                panel1.Width = winSize;
                panel1.Height = winSize;
                panel1.BackColor = System.Drawing.Color.Red;
                komunikat.Visible = false;
            }
            else
            {
                komunikat.Visible = true;
            }
        }

        private void color_Load(object sender, EventArgs e)
        {
            this.ActiveControl = inputSize;
        }

        private void showColorDialog(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                panel1.BackColor = colorDialog1.Color;
            }
            
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            draw d = new draw();
            d.ShowDialog();
        }
    }
}
