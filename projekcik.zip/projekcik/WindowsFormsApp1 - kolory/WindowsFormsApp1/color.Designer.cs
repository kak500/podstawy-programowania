﻿namespace WindowsFormsApp1
{
    partial class color
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnColorClose = new System.Windows.Forms.Button();
            this.btnColorCloseApp = new System.Windows.Forms.Button();
            this.inputSize = new System.Windows.Forms.TextBox();
            this.lblBoxSize = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnShowWindow = new System.Windows.Forms.Button();
            this.komunikat = new System.Windows.Forms.Label();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.button1 = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnColorClose
            // 
            this.btnColorClose.Location = new System.Drawing.Point(61, 212);
            this.btnColorClose.Name = "btnColorClose";
            this.btnColorClose.Size = new System.Drawing.Size(90, 35);
            this.btnColorClose.TabIndex = 0;
            this.btnColorClose.Text = "Zamknij okno";
            this.btnColorClose.UseVisualStyleBackColor = true;
            this.btnColorClose.Click += new System.EventHandler(this.btnColorClose_Click);
            // 
            // btnColorCloseApp
            // 
            this.btnColorCloseApp.Location = new System.Drawing.Point(61, 253);
            this.btnColorCloseApp.Name = "btnColorCloseApp";
            this.btnColorCloseApp.Size = new System.Drawing.Size(90, 35);
            this.btnColorCloseApp.TabIndex = 1;
            this.btnColorCloseApp.Text = "Zamknij program";
            this.btnColorCloseApp.UseVisualStyleBackColor = true;
            this.btnColorCloseApp.Click += new System.EventHandler(this.btnColorCloseApp_Click);
            // 
            // inputSize
            // 
            this.inputSize.Location = new System.Drawing.Point(61, 67);
            this.inputSize.Name = "inputSize";
            this.inputSize.Size = new System.Drawing.Size(90, 20);
            this.inputSize.TabIndex = 2;
            // 
            // lblBoxSize
            // 
            this.lblBoxSize.AutoSize = true;
            this.lblBoxSize.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblBoxSize.Location = new System.Drawing.Point(82, 39);
            this.lblBoxSize.Name = "lblBoxSize";
            this.lblBoxSize.Size = new System.Drawing.Size(49, 25);
            this.lblBoxSize.TabIndex = 3;
            this.lblBoxSize.Text = "Bok";
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(220, 39);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(250, 250);
            this.panel1.TabIndex = 4;
            // 
            // btnShowWindow
            // 
            this.btnShowWindow.Location = new System.Drawing.Point(61, 93);
            this.btnShowWindow.Name = "btnShowWindow";
            this.btnShowWindow.Size = new System.Drawing.Size(90, 35);
            this.btnShowWindow.TabIndex = 5;
            this.btnShowWindow.Text = "Pokaż";
            this.btnShowWindow.UseVisualStyleBackColor = true;
            this.btnShowWindow.Click += new System.EventHandler(this.btnShowWindow_Click);
            // 
            // komunikat
            // 
            this.komunikat.AutoSize = true;
            this.komunikat.Location = new System.Drawing.Point(37, 140);
            this.komunikat.Name = "komunikat";
            this.komunikat.Size = new System.Drawing.Size(143, 13);
            this.komunikat.TabIndex = 6;
            this.komunikat.Text = "Wprowadź prawidłowe dane";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(61, 156);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(90, 35);
            this.button1.TabIndex = 7;
            this.button1.Text = "Kolor...";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.showColorDialog);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.editToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(537, 24);
            this.menuStrip1.TabIndex = 8;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
            this.editToolStripMenuItem.Text = "Edit";
            // 
            // newToolStripMenuItem
            // 
            this.newToolStripMenuItem.Name = "newToolStripMenuItem";
            this.newToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.newToolStripMenuItem.Text = "New";
            this.newToolStripMenuItem.Click += new System.EventHandler(this.newToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // color
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(537, 330);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.komunikat);
            this.Controls.Add(this.btnShowWindow);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lblBoxSize);
            this.Controls.Add(this.inputSize);
            this.Controls.Add(this.btnColorCloseApp);
            this.Controls.Add(this.btnColorClose);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "color";
            this.Text = "color";
            this.Load += new System.EventHandler(this.color_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnColorClose;
        private System.Windows.Forms.Button btnColorCloseApp;
        private System.Windows.Forms.TextBox inputSize;
        private System.Windows.Forms.Label lblBoxSize;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnShowWindow;
        private System.Windows.Forms.Label komunikat;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
    }
}