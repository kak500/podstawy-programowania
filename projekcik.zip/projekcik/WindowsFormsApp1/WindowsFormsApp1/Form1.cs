﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string input = textBox1.Text;
            double input_value;
            if (double.TryParse(input, out input_value) == true && input_value > 0)
            {
                textBox2.Text = (4 * input_value).ToString();
                textBox3.Text = (input_value * input_value).ToString();
                komunikat.ForeColor = System.Drawing.Color.Green;
                komunikat.Text = "Poprawny format";
            }
            else
            {
                textBox2.Text = string.Empty;
                textBox3.Text = string.Empty;
                komunikat.ForeColor = System.Drawing.Color.Red;
                komunikat.Text = "Błędny format";
                Console.WriteLine("Błędny format");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //textBox1.Focus();
            this.ActiveControl = textBox1;
            komunikat.Text = "";
        }

        private void Close_window(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Clear_window(object sender, EventArgs e)
        {
            textBox1.Text = string.Empty;
            textBox2.Text = string.Empty;
            textBox3.Text = string.Empty;
            komunikat.Text = "Wpisz wymiar boku";
        }
    }
}
