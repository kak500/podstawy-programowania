﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TicTacToe
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Winner.Text = "";
            button1.Enabled = false; button2.Enabled = false; button3.Enabled = false; button4.Enabled = false;
            button5.Enabled = false; button6.Enabled = false; button8.Enabled = false; button9.Enabled = false;
            this.ActiveControl = startButton;
        }

        public string player;
        public bool matchFinished;
        private void button_click(object sender, EventArgs e)
        {
            Button b = sender as Button;

            bool[,] board_state = new bool[3, 3] {
                { button1.Enabled, button2.Enabled, button3.Enabled},
                { button4.Enabled, button5.Enabled, button6.Enabled},
                { button7.Enabled, button8.Enabled, button9.Enabled}
            };
            int count_disabled = 0;
            for (int i = 0; i < board_state.GetLength(0); i++)
            {
                for (int j = 0; j < board_state.GetLength(1); j++)
                {
                    if (board_state[i, j] == false)
                    {
                        count_disabled++;
                    }
                    Console.Write("{0}\t", board_state[i, j]);
                }
                Console.WriteLine();

            }
            if (count_disabled == 9 && matchFinished == false)
            {
                WhichPlayer.Text = "Draw";
                matchFinished = true;
            }

            if (player == "X")
            {
                b.Text = "X";
                player = "O";
                WhichPlayer.Text = $"Now it's player {player} move";
            }
            else
            {
                b.Text = "O";
                player = "X";
                WhichPlayer.Text = $"Now it's player {player} move";
            }
            b.Enabled = false;

            // Initilizing of board array
            string[,] board = new string[3, 3] {
                { button1.Text, button2.Text, button3.Text},
                { button4.Text, button5.Text, button6.Text},
                { button7.Text, button8.Text, button9.Text}
            };

           



            // Console.WriteLine(button1.Enabled.GetType());

            for (int i = 0; i < board.GetLength(0); i++)
            {
                for (int j = 0; j < board.GetLength(1); j++)
                {
                    Console.Write("{0}\t", board[i, j]);
                }
                Console.WriteLine();
            }
            // -----Win conditions---------

            for (int x = 0; x < board.GetLength(0); x++)
            {
                for (int y = 0; y < board.GetLength(1); y++)
                {
                    // Horizontally
                    if (board[x, 0] == "X" && board[x, 1] == "X" && board[x, 2] == "X")
                    {
                        WhichPlayer.Text = "Player X won";
                        button1.Enabled = false; button2.Enabled = false; button3.Enabled = false; button4.Enabled = false;
                        button5.Enabled = false; button6.Enabled = false; button8.Enabled = false; button9.Enabled = false;
                    }

                    if (board[x, 0] == "O" && board[x, 1] == "O" && board[x, 2] == "O")
                    {
                        WhichPlayer.Text = "Player O won";
                        button1.Enabled = false; button2.Enabled = false; button3.Enabled = false; button4.Enabled = false;
                        button5.Enabled = false; button6.Enabled = false; button8.Enabled = false; button9.Enabled = false;
                    }

                    // Vertically
                    if (board[0, y] == "X" && board[1, y] == "X" && board[2, y] == "X")
                    {
                        WhichPlayer.Text = "Player X won";
                        button1.Enabled = false; button2.Enabled = false; button3.Enabled = false; button4.Enabled = false;
                        button5.Enabled = false; button6.Enabled = false; button8.Enabled = false; button9.Enabled = false;
                    }

                    if (board[0, y] == "O" && board[1, y] == "O" && board[2, y] == "O")
                    {
                        WhichPlayer.Text = "Player O won";
                        button1.Enabled = false; button2.Enabled = false; button3.Enabled = false; button4.Enabled = false;
                        button5.Enabled = false; button6.Enabled = false; button8.Enabled = false; button9.Enabled = false;
                    }
                }
                Console.WriteLine();
            }

            // Across Top-Left to Bottom-Right
            if (board[0, 0] == "X" && board[1, 1] == "X" && board[2, 2] == "X")
            {
                WhichPlayer.Text = "Player X won";
                button1.Enabled = false; button2.Enabled = false; button3.Enabled = false; button4.Enabled = false;
                button5.Enabled = false; button6.Enabled = false; button8.Enabled = false; button9.Enabled = false;
            }
            if (board[0, 1] == "O" && board[1, 1] == "O" && board[2, 1] == "O")
            {
                WhichPlayer.Text = "Player O won";
                button1.Enabled = false; button2.Enabled = false; button3.Enabled = false; button4.Enabled = false;
                button5.Enabled = false; button6.Enabled = false; button8.Enabled = false; button9.Enabled = false;
            }

            // Across Bottom-Left to Top-Right
            if (board[2, 0] == "X" && board[1, 1] == "X" && board[0, 2] == "X")
            {
                WhichPlayer.Text = "Player X won";
                button1.Enabled = false; button2.Enabled = false; button3.Enabled = false; button4.Enabled = false;
                button5.Enabled = false; button6.Enabled = false; button8.Enabled = false; button9.Enabled = false;
            }
            if (board[2, 0] == "O" && board[1, 1] == "O" && board[0, 2] == "O")
            {
                WhichPlayer.Text = "Player O won";
                button1.Enabled = false; button2.Enabled = false; button3.Enabled = false; button4.Enabled = false;
                button5.Enabled = false; button6.Enabled = false; button8.Enabled = false; button9.Enabled = false;
            }
        }
        
        private void start_game(object sender, EventArgs e)
        {
            Random rnd = new Random();
            int player_toss = rnd.Next(0,2);
            Console.WriteLine(player_toss);
            player = player_toss == 0 ? "X" : "O";
            Console.WriteLine("Player: {0}",player);

            button1.Enabled = true; button2.Enabled = true; button3.Enabled = true; button4.Enabled = true;
            button5.Enabled = true; button6.Enabled = true; button8.Enabled = true; button9.Enabled = true;
            button7.Enabled = true;

            button1.Text = "";
            button2.Text = "";
            button3.Text = "";
            button4.Text = "";
            button5.Text = "";
            button6.Text = "";
            button7.Text = "";
            button8.Text = "";
            button9.Text = "";
            WhichPlayer.Text = "";
            WhichPlayer.Visible = true;
            WhichPlayer.Text = $"Player {player} starts";
            matchFinished = false;
        }
        
    }
}
